@echo off
rem Parche Drive para la app de escritorio: ejecuta patch_drive.py con el
rem Python que ya usa la app (uv, py, python, o el entorno .venv).
setlocal
cd /d "%~dp0"
set "PY="
for %%U in (uv.exe) do if not "%%~$PATH:U" == "" set "PY=uv run --quiet python"
if not defined PY for /f "delims=" %%I in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "PY=%%I"
if not defined PY for /f "delims=" %%I in ('python -c "import sys;print(sys.executable)" 2^>nul') do set "PY=%%I"
if not defined PY if exist ".venv\Scripts\python.exe" set "PY=.venv\Scripts\python.exe"
if not defined PY if exist ".venv-pip\Scripts\python.exe" set "PY=.venv-pip\Scripts\python.exe"
if not defined PY (
  echo.
  echo  No encuentro Python. Abre primero la app con Iniciar.bat una vez,
  echo  y luego vuelve a probar este archivo.
  echo.
  pause
  exit /b 1
)
%PY% "%~dp0patch_drive.py"
echo.
pause
