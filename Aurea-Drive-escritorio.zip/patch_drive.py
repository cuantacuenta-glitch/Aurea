#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Parche para añadir sincronización con Google Drive a la app de escritorio.

Uso: copia este archivo, drive_sync.py y sincronizar.py en la carpeta de la
app (donde está Iniciar.bat, al lado de la carpeta app/ y de mis_datos/),
y ejecuta:  python patch_drive.py
(o doble clic en Patch_Drive.bat, que busca Python por ti).

Hace copia de seguridad de los archivos que toca (*.antes_drive, solo la
primera vez) y, si ya está aplicado, no hace nada. Después, cierra la app
y vuelve a abrirla con Iniciar.bat. En Mis datos -> Copias y exportar ->
Sincronización con Google Drive, pega el ID de cliente de Google, conecta
y a partir de ahí sincroniza sola.

No toca mis_datos ni tus datos: solo añade código a servidor.py,
editor.js y app.js.
"""
import os
import shutil
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(BASE, "app")

ENDPOINTS = '# ---------------------------------------------------------------- sincronización automática con Google Drive\n# Ver app/drive_sync.py. El usuario final solo inicia sesión con Google\n# una vez; después sube al guardar y baja al abrir, automáticamente.\n\n@app.get("/api/drive/estado")\ndef api_drive_estado():\n    return jsonify(ok=True, **drive_sync.leer_estado_drive(DATOS))\n\n\n@app.post("/api/drive/configurar")\ndef api_drive_configurar():\n    datos = request.get_json(silent=True) or {}\n    try:\n        client_id = drive_sync.guardar_config(DATOS, datos.get("client_id"))\n    except drive_sync.ErrorDrive as e:\n        return jsonify(ok=False, errores=[str(e)]), 400\n    return jsonify(ok=True, client_id=client_id)\n\n\n@app.get("/api/drive/conectar")\ndef api_drive_conectar():\n    config = drive_sync.leer_config(DATOS)\n    if not config.get("client_id"):\n        return jsonify(ok=False, errores=["Falta el ID de cliente de Google: pégalo primero en Sincronización."]), 400\n    redirect_uri = "http://%s/api/drive/callback" % request.host\n    url = drive_sync.url_autorizacion(DATOS, config["client_id"], redirect_uri)\n    return jsonify(ok=True, url=url)\n\n\n@app.get("/api/drive/callback")\ndef api_drive_callback():\n    # Viene del navegador del sistema, no del WebView: no tiene llave.\n    error = request.args.get("error")\n    llave = token_acceso()\n    enlace = "http://127.0.0.1:%s/?acceso=%s" % (PUERTO, llave)\n    if error:\n        return Response("<html><body style=\'font-family:sans-serif;padding:40px\'><h2>No se conectó Drive</h2>"\n                        "<p>Google devolvió: %s</p><p><a href=\'%s\'>Volver a la app</a></p></body></html>"\n                        % (error, enlace), mimetype="text/html")\n    config = drive_sync.leer_config(DATOS)\n    if not config.get("client_id"):\n        return Response("<html><body style=\'font-family:sans-serif;padding:40px\'><h2>Falta el ID de cliente</h2>"\n                        "<p><a href=\'%s\'>Volver a la app</a></p></body></html>" % enlace, mimetype="text/html")\n    try:\n        drive_sync.intercambiar_codigo(DATOS, config["client_id"],\n                                       request.args.get("code") or "", request.args.get("state") or "")\n        try:\n            with cerrojo:\n                resumen = drive_sync.sincronizar(DATOS)\n            recalcula(descargar=False)\n            detalle = "Sincronizado: añadidos %s, actualizados %s." % (resumen.get("anadidos", 0), resumen.get("actualizados", 0))\n            if resumen.get("conflictos"):\n                detalle += " Hay %d conflictos: se quedó la versión de este dispositivo." % len(resumen["conflictos"])\n        except Exception as e:\n            detalle = "Conectado, pero la primera sincronización falló (%s). La app lo reintentará al abrir." % e\n        return Response("<html><body style=\'font-family:sans-serif;padding:40px\'><h2>Drive conectado ✓</h2>"\n                        "<p>%s</p><p><a href=\'%s\'>Volver a la app</a></p></body></html>"\n                        % (detalle, enlace), mimetype="text/html")\n    except Exception as e:\n        return Response("<html><body style=\'font-family:sans-serif;padding:40px\'><h2>No se pudo conectar Drive</h2>"\n                        "<p>%s</p><p><a href=\'%s\'>Volver a la app</a></p></body></html>"\n                        % (e, enlace), mimetype="text/html")\n\n\n@app.post("/api/drive/sincronizar")\ndef api_drive_sincronizar():\n    if modo() == "todos":\n        return bloqueado()\n    try:\n        antes = drive_sync._hash_estado(sincronizar.leer_estado(DATOS))\n        with cerrojo:\n            resumen = drive_sync.sincronizar(DATOS)\n        recalcula(descargar=False)\n        despues = drive_sync._hash_estado(sincronizar.leer_estado(DATOS))\n        return jsonify(ok=True, resumen=resumen, cambiado=antes != despues)\n    except drive_sync.ErrorDrive as e:\n        return jsonify(ok=False, errores=[str(e)]), 400\n    except Exception as e:\n        logging.exception("Fallo al sincronizar con Drive")\n        return jsonify(ok=False, errores=[str(e)]), 400\n\n\n@app.post("/api/drive/desconectar")\ndef api_drive_desconectar():\n    drive_sync.borrar_token(DATOS)\n    return jsonify(ok=True)\n\n\n'
FONDO = 'def _drive_fondo():\n    """Sube los cambios a Drive en segundo plano, si está conectado.\n    Nunca bloquea ni rompe un guardado si Drive falla o no hay red."""\n    try:\n        if not drive_sync.leer_config(DATOS).get("client_id") or not drive_sync.leer_token(DATOS):\n            return\n    except Exception:\n        return\n    def trabajo():\n        try:\n            with cerrojo:\n                drive_sync.sincronizar(DATOS)\n            recalcula(descargar=False)\n        except Exception:\n            pass\n    threading.Thread(target=trabajo, daemon=True).start()\n\n\n'
SECCION = '      <section class="tarjeta"><header><h2>Sincronización con Google Drive</h2>\n        <span class="subt">Automática: al guardar sube, al abrir baja. Solo en tu Drive, en la carpeta oculta de la app.</span></header>\n      <p class="ayuda" style="margin-top:0">Inicia sesión con Google una vez y olvídate: tus cambios en el móvil aparecen en el ordenador y al revés, sin mandar archivos. Los datos quedan en tu cuenta de Google, no en un servidor del desarrollador, y la app solo puede ver su propia carpeta oculta, no el resto de tu Drive.</p>\n      <div id="driveEstado"><p class="cargando">Cargando…</p></div>\n      <div id="driveSinCliente" hidden>\n        <p class="ayuda">Falta el ID de cliente de Google del proyecto de la app. Lo crea el desarrollador una vez en Google Cloud (gratis); en la versión de Play Store ya vendrá puesto.</p>\n        <input id="driveCliente" placeholder="123456789012-abc.apps.googleusercontent.com" style="width:100%;box-sizing:border-box">\n        <div class="imAcc" style="margin-top:10px"><span class="sp"></span><button class="btn prim" data-acc="driveGuardarCliente">Guardar ID</button></div>\n        <div class="imErr" id="driveFallo" hidden></div></div>\n      <div id="driveSinConectar" hidden>\n        <p class="ayuda">Ya está configurado. Pulsa Conectar, inicia sesión con tu cuenta de Google en el navegador y acepta el permiso para la carpeta de la app. Después, todo va solo.</p>\n        <button class="btn prim" data-acc="driveConectar">Conectar con Google Drive</button></div>\n      <div id="driveConectado" hidden>\n        <p class="ayuda" id="driveConectadoTexto"></p>\n        <div class="imAcc"><button class="btn prim" data-acc="driveSincronizar">Sincronizar ahora</button>\n          <button class="btn" data-acc="driveDesconectar">Desconectar</button></div>\n        <div id="driveResumen" hidden style="margin-top:12px"></div></div>\n      </section>\n\n'
FUNCS = '  async function driveGuardarCliente() {\n    const v = $("#driveCliente").value.trim(), fallo = $("#driveFallo");\n    fallo.hidden = true;\n    if (!v) { fallo.textContent = "Pega primero el ID de cliente."; fallo.hidden = false; return; }\n    const j = await api("POST", "api/drive/configurar", { client_id: v }).catch(e => ({ ok: false, errores: [e.message] }));\n    if (!j.ok) { fallo.textContent = (j.errores || ["No se pudo guardar."]).join("\\n"); fallo.hidden = false; return; }\n    pinta();\n  }\n\n  async function driveConectar() {\n    const j = await api("GET", "api/drive/conectar").catch(e => ({ ok: false, errores: [e.message] }));\n    if (!j.ok) { alert((j.errores || ["No se pudo conectar."]).join("\\n")); return; }\n    window.location.href = j.url;\n  }\n\n  async function driveSincronizar() {\n    const res = $("#driveResumen"); res.hidden = false; res.innerHTML = \'<p class="cargando">Sincronizando…</p>\';\n    const j = await api("POST", "api/drive/sincronizar").catch(e => ({ ok: false, errores: [e.message] }));\n    if (!j.ok) { res.innerHTML = `<div class="imErr">${esc((j.errores || ["No se pudo sincronizar."]).join("\\n"))}</div>`; return; }\n    const s = j.resumen || {};\n    const conf = (s.conflictos || []).map(c => `<li>${esc(c)}</li>`).join("");\n    res.innerHTML = `<div class="exito"><b>✓ Sincronizado.</b> Añadidos: ${s.anadidos || 0} · Actualizados: ${s.actualizados || 0} · Borrados: ${s.borrados || 0}.</div>`\n      + (conf ? `<p class="ayuda"><b>Conflictos (me quedé con la versión de este dispositivo):</b></p><ul>${conf}</ul>` : `<p class="ayuda">Sin conflictos.</p>`)\n      + (j.cambiado ? `<div class="imAcc" style="margin-top:10px"><button class="btn prim" data-acc="verPanelDatos">Ver mi panel →</button></div>` : "");\n  }\n\n  async function driveDesconectar() {\n    if (!confirm("¿Desconectar Google Drive? Tus datos se quedan en este dispositivo y en tu Drive, pero ya no se sincronizarán solos.")) return;\n    await api("POST", "api/drive/desconectar").catch(() => ({}));\n    pinta();\n  }\n\n  async function driveActualizarEstado() {\n    const est = $("#driveEstado"); if (!est) return;\n    const j = await api("GET", "api/drive/estado").catch(() => null);\n    if (!j) { est.innerHTML = \'<p class="ayuda">No se pudo comprobar el estado de Drive.</p>\'; return; }\n    $("#driveSinCliente").hidden = j.client_id_configurado;\n    $("#driveSinConectar").hidden = !j.client_id_configurado || j.conectado;\n    $("#driveConectado").hidden = !j.conectado;\n    if (!j.client_id_configurado) est.innerHTML = \'<p class="ayuda">Drive sin configurar.</p>\';\n    else if (!j.conectado) est.innerHTML = \'<p class="ayuda">Drive configurado, sin conectar.</p>\';\n    else {\n      const ult = j.ultima_sync ? `Última sincronización: ${j.ultima_sync.slice(0, 10)} ${j.ultima_sync.slice(11, 16)}.` : "Aún sin sincronizar.";\n      const err = j.ultimo_error ? `<br><span style="color:#b00">Último error: ${esc(j.ultimo_error)}</span>` : "";\n      est.innerHTML = `<p class="ayuda"><b>✓ Conectado a Google Drive.</b> ${ult}${err}</p>`;\n      $("#driveConectadoTexto").innerHTML = est.innerHTML;\n    }\n  }\n\n'
APPJS = '  // Sincronización automática con Drive al abrir: no bloquea la primera\n  // pintura; si el otro dispositivo cambió algo, se recarga una vez.\n  setTimeout(() => {\n    fetch("api/drive/sincronizar", { method: "POST" }).then(r => r.json()).then(j => {\n      if (j && j.ok && j.cambiado) location.reload();\n    }).catch(() => {});\n  }, 800);'


def backup(ruta):
    bak = ruta + ".antes_drive"
    if not os.path.exists(bak):
        shutil.copy(ruta, bak)
        print("  Copia de seguridad: %s" % bak)


def parchear(ruta, transformaciones):
    with open(ruta, "r", encoding="utf-8") as f:
        t = f.read()
    original = t
    for nombre, viejo, nuevo in transformaciones:
        if viejo not in t:
            print("  AVISO: no encontré %s en %s, lo salto." % (nombre, os.path.basename(ruta)))
            continue
        t = t.replace(viejo, nuevo, 1)
    if t != original:
        backup(ruta)
        with open(ruta, "w", encoding="utf-8") as f:
            f.write(t)
        print("  Parcheado: %s" % os.path.basename(ruta))
    else:
        print("  Sin cambios: %s" % os.path.basename(ruta))
    return t


def main():
    print("Parche Drive para la app de escritorio")
    print("Carpeta: %s" % BASE)
    for nombre in ("drive_sync.py", "sincronizar.py"):
        origen = os.path.join(BASE, nombre)
        destino = os.path.join(APP, nombre)
        if not os.path.exists(origen):
            print("  FALTA %s en esta carpeta. Copia los 3 archivos juntos." % nombre)
            return 1
        shutil.copy(origen, destino)
        print("  Copiado: app/%s" % nombre)
    serv = os.path.join(APP, "servidor.py")
    if not os.path.exists(serv):
        print("  No encuentro app/servidor.py. ¿Estás en la carpeta de la app?")
        return 1
    with open(serv, encoding="utf-8") as f:
        contenido = f.read()
    if "/api/drive/estado" in contenido:
        print("  La sincronización con Drive ya estaba aplicada en servidor.py.")
    else:
        parchear(serv, [
            ("import", "from . import almacen, almacen_presupuesto, buscar, exportar, fiscal, importar, motor, periodicas, plantilla, red",
             "from . import almacen, almacen_presupuesto, buscar, exportar, fiscal, importar, motor, periodicas, plantilla, red, sincronizar, drive_sync"),
            ("callback exento", '    if request.path == "/api/ping":\n        return None',
             '    if request.path == "/api/ping":\n        return None\n    if request.path == "/api/drive/callback":\n        # El navegador del sistema vuelve aquí desde Google sin la llave de\n        # la app: la seguridad es el estado PKCE aleatorio, no la llave.\n        return None'),
            ("fondo", "def cambia(fn):", FONDO + "def cambia(fn):"),
            ("cambia llama fondo", '        datos = recalcula(descargar="faltan")\n    completa_exposiciones()\n    return jsonify(ok=True, item=item, cartera=cfg, avisos=(datos or {}).get("avisos", []))',
             '        datos = recalcula(descargar="faltan")\n    completa_exposiciones()\n    _drive_fondo()\n    return jsonify(ok=True, item=item, cartera=cfg, avisos=(datos or {}).get("avisos", []))'),
            ("endpoints", "# ---------------------------------------------------------------- web estática y versión",
             ENDPOINTS + "# ---------------------------------------------------------------- web estática y versión"),
        ])
    ed = os.path.join(APP, "web", "editor.js")
    if os.path.exists(ed):
        with open(ed, encoding="utf-8") as f:
            contenido_ed = f.read()
        if "Sincronización con Google Drive" not in contenido_ed:
            parchear(ed, [
                ("sección Drive", '      <section class="tarjeta"><header><h2>Tus datos en Excel</h2>',
                 SECCION + '      <section class="tarjeta"><header><h2>Tus datos en Excel</h2>'),
                ("funciones Drive", "  async function recuperarCopia(archivo) {",
                 FUNCS + "  async function recuperarCopia(archivo) {"),
                ("acciones Drive", "    subirCopia,\n",
                 "    subirCopia,\n    driveGuardarCliente,\n    driveConectar,\n    driveSincronizar,\n    driveDesconectar,\n"),
                ("estado Drive", '    if (IMP.origen === "ia" && !IMP.prompt) {',
                 '    driveActualizarEstado();\n    if (IMP.origen === "ia" && !IMP.prompt) {'),
            ])
        else:
            print("  La sección Drive ya estaba en editor.js.")
    aj = os.path.join(APP, "web", "app.js")
    if os.path.exists(aj):
        with open(aj, encoding="utf-8") as f:
            contenido_aj = f.read()
        if "api/drive/sincronizar" not in contenido_aj:
            parchear(aj, [
                ("sync al abrir", "  actualizaVivo();\n  setInterval(actualizaVivo, 60000);",
                 "  actualizaVivo();\n  setInterval(actualizaVivo, 60000);\n" + APPJS),
            ])
        else:
            print("  La sincronización al abrir ya estaba en app.js.")
    print()
    print("Listo. Cierra la app y ábrela de nuevo con Iniciar.bat.")
    print("En Mis datos -> Copias y exportar -> Sincronización con Google Drive,")
    print("pega el ID de cliente, conecta con Google y a partir de ahí va sola.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(1)
