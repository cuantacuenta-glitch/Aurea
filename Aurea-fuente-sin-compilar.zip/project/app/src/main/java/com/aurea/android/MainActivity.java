package com.aurea.android;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.ProductDetailsResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.OutputStream;
import java.net.URLDecoder;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 1001;

    /* ---------------- Aurea Plus: facturación real Google Play Billing 7.1.1 ----------------
       Productos (a crear en Play Console con estos IDs exactos):
         aurea_plus_anual   (anual, prueba gratis 30 días)
         aurea_plus_mensual (mensual)
       El derecho Plus se guarda en SharedPreferences privadas (no en localStorage
       web): sin conexión se usa el último estado conocido y se vuelve a comprobar
       al recuperar conexión. Nunca se desbloquea Plus sin una compra PURCHASED
       confirmada por Play; sin Play, sin productos o con error, la app sigue en
       Gratis y la pantalla Plus lo dice. La compra real NO se puede probar en
       este entorno (sin Play Store ni productos en Console). */
    private static final String PROD_ANUAL = "aurea_plus_anual";
    private static final String PROD_MENSUAL = "aurea_plus_mensual";
    private static final String PREFS_PLUS = "aurea_plus";
    private BillingClient facturacion = null;
    private final Handler manejador = new Handler(Looper.getMainLooper());
    private final Map<String, ProductDetails> detallesPlus = new HashMap<String, ProductDetails>();
    private long ultimaConsultaCompras = 0;
    private boolean detallesCargados = false;
    private boolean restaurarPedido = false;
    private String compraPendiente = null;
    private boolean compraPendientePrueba = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Cabecera NUNCA bajo la barra de estado ni bajo el notch: NO se dibuja
        // borde a borde arriba y NO se adivina la altura con un padding CSS (el
        // WebView informa env(safe-area-inset-top)=0 y el modo "pantalla completa"
        // de Huawei coloca la ventana en la zona del notch, por eso el padding de
        // 40px no bastaba). En su lugar, el sistema coloca el WebView con los
        // insets reales del dispositivo (setDecorFitsSystemWindows(true)) y, desde
        // Android 9, LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER prohíbe la zona del
        // notch aunque el usuario tenga activada la pantalla completa. La barra
        // de navegación inferior sigue oculta en inmersivo (ocultarBarraSistema(),
        // arreglo de 4.6, sin tocar), y el padding CSS de 40px queda solo como
        // capa extra de seguridad. No volver a poner borde a borde arriba.
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                getWindow().setDecorFitsSystemWindows(true);
                getWindow().setStatusBarColor(Color.parseColor("#0a0e14"));
                getWindow().setNavigationBarColor(Color.parseColor("#0a0e14"));
                getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.parseColor("#0a0e14")));
                android.view.WindowInsetsController ic = getWindow().getInsetsController();
                if (ic != null) ic.setSystemBarsAppearance(0,
                        android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
                getWindow().setStatusBarColor(Color.parseColor("#0a0e14"));
                getWindow().setNavigationBarColor(Color.parseColor("#0a0e14"));
                getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.parseColor("#0a0e14")));
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                WindowManager.LayoutParams attrs = getWindow().getAttributes();
                attrs.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER;
                getWindow().setAttributes(attrs);
            }
        } catch (Exception ignored) {
        }
        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#0a0e14"));
        ocultarBarraSistema();
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setBuiltInZoomControls(false);
        // Rendimiento: caché en disco para los scripts (con sello fijo
        // en Android) y render por hardware.
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        }
        webView.addJavascriptInterface(new Puente(), "AureaAndroid");
        iniciarFacturacion();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                // La página ya está cargada: si Billing ya trajo precios, se los
                // pasa a la pantalla Plus (antes de cargar, el puente aún no existe
                // en la web y enviarPreciosAWeb no haría nada).
                try { enviarPreciosAWeb(); } catch (Exception ignored) {}
                // Al arrancar, primero se carga una página "Arrancando…" con
                // loadData y luego la URL real del servidor local con loadUrl:
                // eso deja dos entradas en el historial y el primer atrás
                // volvía a la pantalla de arranque (fondo oscuro #0a0e14).
                // Al terminar la carga de la página local se borra el historial
                // anterior (clearHistory conserva la página actual): desde la
                // página principal el primer atrás ya no tiene a dónde volver
                // dentro del WebView y onBackPressed() sale de la app. Las
                // pestañas no usan history.pushState ni hash, así que esto no
                // rompe la navegación entre pestañas; una navegación posterior
                // que sí cree historial dentro del WebView seguirá funcionando
                // con normalidad después de este punto.
                try {
                    String host = android.net.Uri.parse(url).getHost();
                    if ("127.0.0.1".equals(host) || "localhost".equals(host)) {
                        view.clearHistory();
                    }
                } catch (Exception ignored) {}
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String host = u.getHost();
                // Solo el servidor local se abre dentro de la app.
                if ("127.0.0.1".equals(host) || "localhost".equals(host)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (ActivityNotFoundException ignored) {
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(Intent.createChooser(intent, "Elige un archivo"), FILE_CHOOSER);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimeType, long contentLength) {
                try {
                    DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                    req.setMimeType(mimeType);
                    String cookie = CookieManager.getInstance().getCookie(url);
                    if (cookie != null) req.addRequestHeader("Cookie", cookie);
                    req.addRequestHeader("User-Agent", userAgent);
                    String nombre = URLUtil.guessFileName(url, contentDisposition, mimeType);
                    req.setTitle(nombre);
                    req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, nombre);
                    ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(req);
                    Toast.makeText(MainActivity.this, "Descargando " + nombre, Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo descargar el archivo", Toast.LENGTH_SHORT).show();
                }
            }
        });

        webView.loadData("<html><body style='background:#0a0e14;color:#f5f1e8;font-family:sans-serif;padding:40px'>"
                + "<h2 style='color:#d4af6a;letter-spacing:.2em;text-transform:uppercase'>Aurea</h2><p>Arrancando… un momento, por favor.</p></body></html>",
                "text/html", "UTF-8");

        new Thread(() -> {
            try {
                if (!Python.isStarted()) Python.start(new AndroidPlatform(MainActivity.this));
                File datos = new File(getFilesDir(), "aurea_datos");
                if (!datos.exists()) datos.mkdirs();
                String res = Python.getInstance().getModule("aurea_android")
                        .callAttr("iniciar", datos.getAbsolutePath()).toString();
                int sep = res.indexOf(':');
                String puerto = res.substring(0, sep);
                String llave = res.substring(sep + 1);
                String url = "http://127.0.0.1:" + puerto + "/?acceso=" + llave;
                // Esperar a que el servidor responda antes de cargar.
                for (int i = 0; i < 60; i++) {
                    try {
                        java.net.HttpURLConnection c = (java.net.HttpURLConnection)
                                new java.net.URL("http://127.0.0.1:" + puerto + "/api/ping").openConnection();
                        c.setConnectTimeout(1000);
                        if (c.getResponseCode() == 200) break;
                    } catch (Exception ignored) {
                    }
                    try { Thread.sleep(500); } catch (InterruptedException ignored) { }
                }
                runOnUiThread(() -> webView.loadUrl(url));
            } catch (Exception e) {
                runOnUiThread(() -> webView.loadData(
                        "<html><body style='font-family:sans-serif;padding:24px'><h2>No se pudo arrancar Aurea</h2>"
                                + "<p>" + e.toString() + "</p><p>Cierra la app y vuelve a abrirla.</p></body></html>",
                        "text/html", "UTF-8"));
            }
        }).start();
    }

    private void ocultarBarraSistema() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.view.WindowInsetsController ic = getWindow().getInsetsController();
                if (ic != null) {
                    ic.hide(android.view.WindowInsets.Type.navigationBars());
                    ic.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                // Pre-R: se oculta la navegación inferior (inmersivo) pero SIN
                // LAYOUT_FULLSCREEN, para que el contenido no vuelva a quedar
                // bajo la barra de estado/notch (es el caso del Huawei P20 Pro,
                // API 29): esta función se llama en onCreate y en cada foco, así
                // que dejar LAYOUT_FULLSCREEN aquí desharía el arreglo superior.
                // LAYOUT_HIDE_NAVIGATION se conserva: la barra inferior sigue
                // oculta y el contenido llega hasta abajo sin franja negra.
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) ocultarBarraSistema();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Al volver de Google Play (o de la app de Play Store), refrescar el
        // derecho Plus: una compra hecha fuera del flujo también debe verse.
        try {
            if (facturacion == null) iniciarFacturacion();
            else if (!facturacion.isReady()) conectarFacturacion(0);
            else consultarCompras(false);
        } catch (Exception ignored) {}
    }

    @Override
    protected void onDestroy() {
        try { if (facturacion != null) facturacion.endConnection(); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] res = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(res);
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    /** La página avisa cuando cambia el tema, para que las barras del sistema sean
        del mismo color que la app (oscuro #0a0e14, claro #faf7f0) y no quede una
        franja negra por debajo de la barra inferior. */
    public void actualizaBarras(String color) {
        runOnUiThread(() -> {
            try {
                int c = Color.parseColor(color);
                getWindow().setStatusBarColor(c);
                getWindow().setNavigationBarColor(c);
            } catch (Exception ignored) {
            }
        });
    }


    /* ---------------- Facturación Plus: helpers (solo MainActivity) ---------------- */

    private static String aJson(String s) {
        if (s == null) return "null";
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"') sb.append("\\\"");
            else if (c == '\\') sb.append("\\\\");
            else if (c == '\n') sb.append("\\n");
            else if (c == '\r') sb.append("\\r");
            else if (c == '\t') sb.append("\\t");
            else if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
            else sb.append(c);
        }
        sb.append("\"");
        return sb.toString();
    }

    private boolean plusCache() {
        try {
            return getSharedPreferences(PREFS_PLUS, MODE_PRIVATE).getBoolean("plus_activo", false);
        } catch (Exception e) {
            return false;
        }
    }

    private void guardarPlusCache(boolean activo) {
        try {
            SharedPreferences.Editor ed = getSharedPreferences(PREFS_PLUS, MODE_PRIVATE).edit();
            ed.putBoolean("plus_activo", activo);
            ed.putLong("plus_actualizado", System.currentTimeMillis());
            ed.apply();
        } catch (Exception ignored) {}
    }

    private void avisarWeb(final String msg) {
        runOnUiThread(new Runnable() {
            public void run() {
                try {
                    if (webView != null) {
                        webView.evaluateJavascript("window.AureaPlus && window.AureaPlus.aviso && window.AureaPlus.aviso(" + aJson(msg) + ")", null);
                    } else {
                        Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    try { Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show(); } catch (Exception ignored) {}
                }
            }
        });
    }

    private void recargarWeb() {
        runOnUiThread(new Runnable() {
            public void run() {
                try { if (webView != null) webView.evaluateJavascript("location.reload()", null); } catch (Exception ignored) {}
            }
        });
    }

    private String mensajeErrorCompra(int code) {
        if (code == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
            return "Ya tienes una suscripción de Aurea Plus activa: pulsa «Restaurar compra» para activarla en este dispositivo.";
        }
        if (code == BillingClient.BillingResponseCode.ITEM_UNAVAILABLE) {
            return "Aurea Plus no está disponible en Google Play todavía: falta crear los productos aurea_plus_anual y aurea_plus_mensual en Play Console y publicar la app. Sigues en el plan gratis, sin ningún cargo.";
        }
        if (code == BillingClient.BillingResponseCode.DEVELOPER_ERROR) {
            return "Error de configuración de la compra en Google Play (revisa los IDs de producto en Play Console). Sigues en el plan gratis.";
        }
        if (code == BillingClient.BillingResponseCode.BILLING_UNAVAILABLE
                || code == BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE) {
            return "Google Play no está disponible en este dispositivo o para tu cuenta en este momento. Sigues en el plan gratis.";
        }
        if (code == BillingClient.BillingResponseCode.SERVICE_DISCONNECTED
                || code == BillingClient.BillingResponseCode.SERVICE_TIMEOUT
                || code == BillingClient.BillingResponseCode.NETWORK_ERROR) {
            return "No se pudo conectar con Google Play, revisa tu conexión e inténtalo de nuevo. Sigues en el plan gratis.";
        }
        if (code == BillingClient.BillingResponseCode.FEATURE_NOT_SUPPORTED) {
            return "Tu versión de Google Play no admite suscripciones. Actualiza Google Play e inténtalo de nuevo.";
        }
        return "No se pudo completar la compra en Google Play (código " + code + "). Sigues en el plan gratis, sin ningún cargo.";
    }

    private final PurchasesUpdatedListener oyenteCompras = new PurchasesUpdatedListener() {
        public void onPurchasesUpdated(BillingResult result, List<Purchase> purchases) {
            try {
                int code = result.getResponseCode();
                if (code == BillingClient.BillingResponseCode.OK && purchases != null) {
                    // Primero las compradas (tienen prioridad sobre las pendientes).
                    for (Purchase p : purchases) {
                        if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                            List<String> prods = p.getProducts();
                            if (prods != null && (prods.contains(PROD_ANUAL) || prods.contains(PROD_MENSUAL))) {
                                guardarPlusCache(true);
                                if (!p.isAcknowledged()) confirmarCompra(p);
                                recargarWeb();
                                return;
                            }
                        }
                    }
                    for (Purchase p : purchases) {
                        if (p.getPurchaseState() == Purchase.PurchaseState.PENDING) {
                            avisarWeb("Tu pago está pendiente de confirmación en Google Play (por ejemplo, pago en efectivo): Plus se activará solo cuando Play lo confirme, sin que tengas que hacer nada más.");
                            return;
                        }
                    }
                    return;
                }
                if (code == BillingClient.BillingResponseCode.USER_CANCELED) {
                    avisarWeb("Compra cancelada. Sigues en el plan gratis, sin ningún cargo.");
                    return;
                }
                avisarWeb(mensajeErrorCompra(code));
            } catch (Exception ignored) {}
        }
    };

    private void iniciarFacturacion() {
        try {
            if (facturacion != null) {
                if (!facturacion.isReady()) conectarFacturacion(0);
                return;
            }
            facturacion = BillingClient.newBuilder(MainActivity.this)
                    .setListener(oyenteCompras)
                    .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                    .build();
            conectarFacturacion(0);
        } catch (Exception e) {
            facturacion = null;
        }
    }

    private void conectarFacturacion(final int intento) {
        try {
            if (facturacion == null) return;
            if (facturacion.isReady()) {
                consultarDetalles();
                consultarCompras(false);
                enviarPreciosAWeb();
                return;
            }
            facturacion.startConnection(new BillingClientStateListener() {
                public void onBillingSetupFinished(BillingResult result) {
                    try {
                        if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                            consultarDetalles();
                            consultarCompras(false);
                            enviarPreciosAWeb();
                        } else if (intento < 3) {
                            long espera = intento == 0 ? 3000L : (intento == 1 ? 10000L : 30000L);
                            manejador.postDelayed(new Runnable() {
                                public void run() { conectarFacturacion(intento + 1); }
                            }, espera);
                        }
                    } catch (Exception ignored) {}
                }

                public void onBillingServiceDisconnected() {
                    manejador.postDelayed(new Runnable() {
                        public void run() { conectarFacturacion(0); }
                    }, 5000);
                }
            });
        } catch (Exception ignored) {}
    }

    private void consultarDetalles() {
        try {
            if (facturacion == null || !facturacion.isReady()) return;
            List<QueryProductDetailsParams.Product> lista = new ArrayList<QueryProductDetailsParams.Product>();
            lista.add(QueryProductDetailsParams.Product.newBuilder().setProductId(PROD_ANUAL).setProductType(BillingClient.ProductType.SUBS).build());
            lista.add(QueryProductDetailsParams.Product.newBuilder().setProductId(PROD_MENSUAL).setProductType(BillingClient.ProductType.SUBS).build());
            QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder().setProductList(lista).build();
            facturacion.queryProductDetailsAsync(params, new ProductDetailsResponseListener() {
                public void onProductDetailsResponse(BillingResult result, List<ProductDetails> list) {
                    try {
                        detallesCargados = true;
                        if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && list != null) {
                            for (ProductDetails d : list) detallesPlus.put(d.getProductId(), d);
                        }
                        enviarPreciosAWeb();
                        if (compraPendiente != null) {
                            String prod = compraPendiente;
                            boolean prueba = compraPendientePrueba;
                            compraPendiente = null;
                            lanzarCompra(prod, prueba);
                        }
                    } catch (Exception ignored) {}
                }
            });
        } catch (Exception ignored) {}
    }

    private String precioRegular(ProductDetails d) {
        if (d == null) return null;
        try {
            List<ProductDetails.SubscriptionOfferDetails> ofertas = d.getSubscriptionOfferDetails();
            if (ofertas == null) return null;
            String ultimo = null;
            for (ProductDetails.SubscriptionOfferDetails o : ofertas) {
                if (o == null || o.getPricingPhases() == null) continue;
                List<ProductDetails.PricingPhase> fases = o.getPricingPhases().getPricingPhaseList();
                if (fases == null) continue;
                for (ProductDetails.PricingPhase f : fases) {
                    ultimo = f.getFormattedPrice();
                    if (f.getRecurrenceMode() != ProductDetails.RecurrenceMode.NON_RECURRING) return ultimo;
                }
            }
            return ultimo;
        } catch (Exception e) {
            return null;
        }
    }

    private String tokenOferta(ProductDetails d, boolean preferirPrueba) {
        if (d == null) return null;
        try {
            List<ProductDetails.SubscriptionOfferDetails> ofertas = d.getSubscriptionOfferDetails();
            if (ofertas == null || ofertas.isEmpty()) return null;
            if (preferirPrueba) {
                for (ProductDetails.SubscriptionOfferDetails o : ofertas) {
                    if (o == null || o.getPricingPhases() == null) continue;
                    List<ProductDetails.PricingPhase> fases = o.getPricingPhases().getPricingPhaseList();
                    if (fases == null) continue;
                    for (ProductDetails.PricingPhase f : fases) {
                        if (f.getPriceAmountMicros() == 0) return o.getOfferToken();
                    }
                }
            }
            return ofertas.get(0).getOfferToken();
        } catch (Exception e) {
            return null;
        }
    }

    private void enviarPreciosAWeb() {
        try {
            String anualPlay = precioRegular(detallesPlus.get(PROD_ANUAL));
            String mensualPlay = precioRegular(detallesPlus.get(PROD_MENSUAL));
            SharedPreferences prefs = getSharedPreferences(PREFS_PLUS, MODE_PRIVATE);
            if (anualPlay != null || mensualPlay != null) {
                SharedPreferences.Editor ed = prefs.edit();
                if (anualPlay != null) ed.putString("precio_anual", anualPlay);
                if (mensualPlay != null) ed.putString("precio_mensual", mensualPlay);
                ed.apply();
            }
            String anual = anualPlay != null ? anualPlay : prefs.getString("precio_anual", null);
            String mensual = mensualPlay != null ? mensualPlay : prefs.getString("precio_mensual", null);
            if (anual == null && mensual == null) return;
            boolean desdePlay = detallesPlus.containsKey(PROD_ANUAL) || detallesPlus.containsKey(PROD_MENSUAL);
            final String json = "{\"anual\":" + aJson(anual) + ",\"mensual\":" + aJson(mensual)
                    + ",\"desdePlay\":" + (desdePlay ? "true" : "false") + "}";
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        if (webView != null) webView.evaluateJavascript("window.AureaPlus && window.AureaPlus.setPrecios && window.AureaPlus.setPrecios(" + json + ")", null);
                    } catch (Exception ignored) {}
                }
            });
        } catch (Exception ignored) {}
    }

    private void confirmarCompra(Purchase p) {
        try {
            if (facturacion == null || !facturacion.isReady()) return;
            AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.getPurchaseToken()).build();
            facturacion.acknowledgePurchase(params, new AcknowledgePurchaseResponseListener() {
                public void onAcknowledgePurchaseResponse(BillingResult result) {
                    // Si falla (p. ej., sin red), la próxima consulta vuelve a
                    // intentarlo: la compra sigue sin confirmar y se reencola.
                }
            });
        } catch (Exception ignored) {}
    }

    private void consultarCompras(final boolean avisarSiNada) {
        try {
            if (facturacion == null || !facturacion.isReady()) return;
            ultimaConsultaCompras = System.currentTimeMillis();
            QueryPurchasesParams params = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build();
            facturacion.queryPurchasesAsync(params, new PurchasesResponseListener() {
                public void onQueryPurchasesResponse(BillingResult result, List<Purchase> purchases) {
                    try {
                        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                            if (restaurarPedido) {
                                restaurarPedido = false;
                                avisarWeb("No se pudo comprobar con Google Play, revisa tu conexión e inténtalo de nuevo.");
                            }
                            return;
                        }
                        boolean activo = false;
                        List<Purchase> sinConfirmar = new ArrayList<Purchase>();
                        if (purchases != null) {
                            for (Purchase p : purchases) {
                                if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                                    List<String> prods = p.getProducts();
                                    if (prods != null && (prods.contains(PROD_ANUAL) || prods.contains(PROD_MENSUAL))) {
                                        activo = true;
                                        if (!p.isAcknowledged()) sinConfirmar.add(p);
                                    }
                                }
                            }
                        }
                        boolean antes = plusCache();
                        guardarPlusCache(activo);
                        for (Purchase p : sinConfirmar) confirmarCompra(p);
                        if (restaurarPedido) {
                            restaurarPedido = false;
                            if (activo) recargarWeb();
                            else avisarWeb("No se encontró ninguna suscripción de Aurea Plus activa en esta cuenta de Google.");
                        } else if (activo && !antes) {
                            recargarWeb();
                        }
                        // Si Plus se pierde (cancelación/caducidad) no se fuerza
                        // recarga: la próxima pintura ya lo refleja vía esPlus(),
                        // y así no se pierde lo que se esté editando.
                    } catch (Exception ignored) {}
                }
            });
        } catch (Exception ignored) {}
    }

    private void comprarPlan(final String productId, final boolean preferirPrueba) {
        runOnUiThread(new Runnable() {
            public void run() { lanzarCompra(productId, preferirPrueba); }
        });
    }

    private void lanzarCompra(String productId, boolean preferirPrueba) {
        try {
            if (facturacion == null) {
                compraPendiente = productId;
                compraPendientePrueba = preferirPrueba;
                iniciarFacturacion();
                avisarWeb("Conectando con Google Play… pulsa de nuevo en unos segundos si no se abre la compra.");
                return;
            }
            if (!facturacion.isReady()) {
                compraPendiente = productId;
                compraPendientePrueba = preferirPrueba;
                conectarFacturacion(0);
                avisarWeb("Conectando con Google Play… pulsa de nuevo en unos segundos si no se abre la compra.");
                return;
            }
            ProductDetails d = detallesPlus.get(productId);
            if (d == null) {
                if (!detallesCargados) {
                    compraPendiente = productId;
                    compraPendientePrueba = preferirPrueba;
                    consultarDetalles();
                    avisarWeb("Cargando los planes de Aurea Plus en Google Play… pulsa de nuevo en unos segundos.");
                    return;
                }
                avisarWeb("Aurea Plus no está disponible en Google Play todavía: falta crear los productos aurea_plus_anual y aurea_plus_mensual en Play Console y publicar la app. Sigues en el plan gratis, sin ningún cargo.");
                return;
            }
            String token = tokenOferta(d, preferirPrueba);
            if (token == null) {
                avisarWeb("No se pudo preparar la compra de Aurea Plus en Google Play. Inténtalo de nuevo.");
                return;
            }
            List<BillingFlowParams.ProductDetailsParams> lista = new ArrayList<BillingFlowParams.ProductDetailsParams>();
            lista.add(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).setOfferToken(token).build());
            BillingFlowParams params = BillingFlowParams.newBuilder().setProductDetailsParamsList(lista).build();
            BillingResult res = facturacion.launchBillingFlow(MainActivity.this, params);
            if (res.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                avisarWeb(mensajeErrorCompra(res.getResponseCode()));
            }
        } catch (Exception e) {
            avisarWeb("No se pudo abrir la compra en Google Play. Revisa tu conexión e inténtalo de nuevo.");
        }
    }

    /** Puente para descargas que el WebView no gestiona solo (imágenes blob y CSV). */
    public class Puente {
        @JavascriptInterface
        public void setBarras(String color) { actualizaBarras(color); }

        /** Aurea Plus con facturación real Google Play Billing 7.1.1.
            esPlus() devuelve la caché local (SharedPreferences privadas); en
            segundo plano refresca con Play si hace más de 60 s desde la última
            consulta, para no bloquear la pintura ni saturar a Play. comprarPlus()
            es el anual (con preferencia a la oferta con prueba gratis); para el
            mensual está comprarPlusMensual(). Nunca se desbloquea Plus sin una
            compra PURCHASED confirmada por Play: sin Play, sin productos o con
            error, la pantalla Plus lo dice y la app sigue en Gratis. */
        @JavascriptInterface
        public boolean esPlus() {
            boolean cache = plusCache();
            try {
                if (facturacion == null) {
                    manejador.post(new Runnable() {
                        public void run() { iniciarFacturacion(); }
                    });
                } else if (facturacion.isReady()
                        && System.currentTimeMillis() - ultimaConsultaCompras > 60000) {
                    manejador.post(new Runnable() {
                        public void run() { consultarCompras(false); }
                    });
                }
            } catch (Exception ignored) {}
            return cache;
        }

        @JavascriptInterface
        public void comprarPlus() { comprarPlan(PROD_ANUAL, true); }

        @JavascriptInterface
        public void comprarPlusMensual() { comprarPlan(PROD_MENSUAL, false); }

        @JavascriptInterface
        public void restaurarPlus() {
            manejador.post(new Runnable() {
                public void run() {
                    if (facturacion == null) {
                        iniciarFacturacion();
                        avisarWeb("Conectando con Google Play… pulsa Restaurar de nuevo en unos segundos.");
                        return;
                    }
                    if (!facturacion.isReady()) {
                        conectarFacturacion(0);
                        avisarWeb("Conectando con Google Play… pulsa Restaurar de nuevo en unos segundos.");
                        return;
                    }
                    restaurarPedido = true;
                    consultarCompras(true);
                }
            });
        }

        @JavascriptInterface
        public String preciosPlus() {
            try {
                String anual = precioRegular(detallesPlus.get(PROD_ANUAL));
                String mensual = precioRegular(detallesPlus.get(PROD_MENSUAL));
                SharedPreferences prefs = getSharedPreferences(PREFS_PLUS, MODE_PRIVATE);
                if (anual == null) anual = prefs.getString("precio_anual", null);
                if (mensual == null) mensual = prefs.getString("precio_mensual", null);
                boolean desdePlay = detallesPlus.containsKey(PROD_ANUAL) || detallesPlus.containsKey(PROD_MENSUAL);
                return "{\"anual\":" + aJson(anual) + ",\"mensual\":" + aJson(mensual)
                        + ",\"desdePlay\":" + (desdePlay ? "true" : "false") + "}";
            } catch (Exception e) {
                return "{\"anual\":null,\"mensual\":null,\"desdePlay\":false}";
            }
        }

        @JavascriptInterface
        public void guardarArchivo(String dataUrl, String nombre) {
            runOnUiThread(() -> {
                try {
                    byte[] bytes;
                    int coma = dataUrl.indexOf(',');
                    String cab = dataUrl.substring(0, coma);
                    String resto = dataUrl.substring(coma + 1);
                    if (cab.contains(";base64")) bytes = Base64.decode(resto, Base64.DEFAULT);
                    else bytes = URLDecoder.decode(resto, "UTF-8").getBytes("UTF-8");
                    String mime = cab.contains("image/png") ? "image/png" : "text/csv";
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
                        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                            out.write(bytes);
                        }
                    } else {
                        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                        if (!dir.exists()) dir.mkdirs();
                        try (FileOutputStream out = new FileOutputStream(new File(dir, nombre))) {
                            out.write(bytes);
                        }
                    }
                    Toast.makeText(MainActivity.this, "Guardado en Descargas: " + nombre, Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No se pudo guardar el archivo", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
