# -*- coding: utf-8 -*-
"""
almacen_presupuesto.py
======================
Módulo para la persistencia y lectura de datos de presupuesto
dentro de la arquitectura de Aurea 2.0.
"""

import os
import json

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATOS = os.environ.get("PATRIMONIO_DATOS") or os.path.join(RAIZ, "mis_datos")
RUTA_PRESUPUESTO = os.path.join(DATOS, "presupuesto.json")

ESTRUCTURA_BASE = {
    "anios": {}
}

def lee_presupuesto():
    if not os.path.exists(RUTA_PRESUPUESTO):
        guarda_presupuesto(ESTRUCTURA_BASE)
        return ESTRUCTURA_BASE
    try:
        with open(RUTA_PRESUPUESTO, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return ESTRUCTURA_BASE

def guarda_presupuesto(datos):
    os.makedirs(os.path.dirname(RUTA_PRESUPUESTO), exist_ok=True)
    tmp = RUTA_PRESUPUESTO + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)
    os.replace(tmp, RUTA_PRESUPUESTO)

def guardar_mes_real(anio, mes, ingresos, gastos):
    datos = lee_presupuesto()
    anio_str = str(anio)
    mes_str = str(mes).zfill(2)

    if anio_str not in datos["anios"]:
        datos["anios"][anio_str] = {
            "presupuesto": {"ingresos": 0, "gastos": 0},
            "realizado": {}
        }

    if "realizado" not in datos["anios"][anio_str]:
        datos["anios"][anio_str]["realizado"] = {}

    datos["anios"][anio_str]["realizado"][mes_str] = {
        "ingresos": float(ingresos),
        "gastos": float(gastos)
    }
    guarda_presupuesto(datos)
    return datos

def guardar_estimado_anio(anio, ingresos, gastos):
    datos = lee_presupuesto()
    anio_str = str(anio)

    if anio_str not in datos["anios"]:
        datos["anios"][anio_str] = {
            "presupuesto": {},
            "realizado": {}
        }

    datos["anios"][anio_str]["presupuesto"] = {
        "ingresos": float(ingresos),
        "gastos": float(gastos)
    }
    guarda_presupuesto(datos)
    return datos