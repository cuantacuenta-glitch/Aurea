# -*- coding: utf-8 -*-
"""Sincronización automática con Google Drive (carpeta de la app).

Para el usuario final es un toque: "Iniciar sesión con Google" una vez, y
a partir de ahí la app sube sus cambios al abrir y al guardar, y baja los
del otro dispositivo al abrir. Gratis, y sin servidor del desarrollador:
los datos quedan en el Drive de cada usuario, en la carpeta oculta de la
app (appDataFolder, ámbito drive.appdata), que solo esta app puede ver.
No se ven en el Drive normal, no se comparten, y no cuentan casi nada
(una cartera son pocos KB, dentro de los 15 GB gratis de Google).

Flujo (OAuth 2.0 con PKCE, sin secreto en la app, como corresponde a una
app instalada):
  1. La app genera un verificador PKCE y un estado aleatorio, y abre en
     el navegador del sistema la página de Google (Google bloquea el
     inicio de sesión dentro de un WebView, por eso se abre fuera).
  2. Google devuelve a http://127.0.0.1:<puerto>/api/drive/callback un
     código, junto con el estado. El servidor local valida el estado y
     cambia el código por un token de acceso + un token de refresco,
     usando el verificador PKCE. Los tokens quedan en la carpeta privada
     de datos (drive_token.json), nunca en el archivo de sincronización.
  3. A partir de ahí, sincronizar() sube/baja el archivo
     "sincronizacion.json" de appDataFolder, y mezcla con app/sincronizar.py
     usando la última sincronización como base (igual que la sincronización
     por archivo, pero automática).

Solo usa la biblioteca estándar: urllib, json, hashlib, secrets. No hace
falta google-api-python-client, que no cabe bien en la APK.

Para que funcione, el desarrollador crea UNA VEZ un proyecto gratis en
Google Cloud, activa la API de Google Drive y crea un cliente OAuth de
tipo "Aplicación de escritorio". Su ID de cliente se mete en la app
(en Ajustes de sincronización, o preconfigurado en la versión de Play
Store). Los usuarios finales no crean ningún proyecto: solo inician
sesión con su cuenta de Google.
"""

import base64
import datetime as dt
import hashlib
import json
import os
import secrets
import urllib.error
import urllib.parse
import urllib.request

from . import sincronizar as _sync

SCOPE = "https://www.googleapis.com/auth/drive.appdata"
AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
FILES_URL = "https://www.googleapis.com/drive/v3/files"
UPLOAD_URL = "https://www.googleapis.com/upload/drive/v3/files"
NOMBRE_ARCHIVO = "sincronizacion.json"


class ErrorDrive(Exception):
    pass


# ------------------------------------------------------------------ disco

def _ruta(datos_dir, nombre):
    return os.path.join(datos_dir, nombre)


def _leer_json(ruta, defecto=None):
    try:
        with open(ruta, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return defecto


def _escribir_json(ruta, datos):
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    tmp = ruta + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=1)
    os.replace(tmp, ruta)


def leer_config(datos_dir):
    return _leer_json(_ruta(datos_dir, "drive_config.json")) or {}


def guardar_config(datos_dir, client_id):
    client_id = (client_id or "").strip()
    if not client_id:
        raise ErrorDrive("Falta el ID de cliente de Google.")
    # Un ID de cliente de Google termina en .apps.googleusercontent.com
    if "." not in client_id:
        raise ErrorDrive("Ese ID de cliente no parece de Google.")
    _escribir_json(_ruta(datos_dir, "drive_config.json"), {"client_id": client_id})
    return client_id


def leer_token(datos_dir):
    return _leer_json(_ruta(datos_dir, "drive_token.json"))


def _guardar_token(datos_dir, token):
    _escribir_json(_ruta(datos_dir, "drive_token.json"), token)


def borrar_token(datos_dir):
    for nombre in ("drive_token.json", "drive_pkce.json"):
        try:
            os.remove(_ruta(datos_dir, nombre))
        except OSError:
            pass


def leer_estado_drive(datos_dir):
    estado = _leer_json(_ruta(datos_dir, "drive_estado.json")) or {}
    config = leer_config(datos_dir)
    token = leer_token(datos_dir)
    return {"client_id_configurado": bool(config.get("client_id")),
            "conectado": bool(token and token.get("refresh_token")),
            "ultima_sync": estado.get("ultima_sync"),
            "ultimo_resultado": estado.get("ultimo_resultado"),
            "ultimo_error": estado.get("ultimo_error")}


def _actualizar_estado(datos_dir, resultado=None, error=None):
    estado = _leer_json(_ruta(datos_dir, "drive_estado.json")) or {}
    estado["ultima_sync"] = dt.datetime.now().isoformat(timespec="seconds")
    if resultado is not None:
        estado["ultimo_resultado"] = resultado
    estado["ultimo_error"] = error
    _escribir_json(_ruta(datos_dir, "drive_estado.json"), estado)


# ------------------------------------------------------------------ OAuth

def _b64url(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def url_autorizacion(datos_dir, client_id, redirect_uri):
    """Genera la URL de Google y guarda el PKCE/estado para el callback."""
    verifier = _b64url(secrets.token_bytes(64))
    challenge = _b64url(hashlib.sha256(verifier.encode("ascii")).digest())
    state = _b64url(secrets.token_bytes(32))
    _escribir_json(_ruta(datos_dir, "drive_pkce.json"),
                   {"verifier": verifier, "state": state, "redirect_uri": redirect_uri,
                    "creado": dt.datetime.now().isoformat()})
    params = {"client_id": client_id, "redirect_uri": redirect_uri, "response_type": "code",
              "scope": SCOPE, "access_type": "offline", "prompt": "consent",
              "state": state, "code_challenge": challenge, "code_challenge_method": "S256"}
    return AUTH_URL + "?" + urllib.parse.urlencode(params)


def _post_form(url, datos):
    cuerpo = urllib.parse.urlencode(datos).encode("ascii")
    req = urllib.request.Request(url, data=cuerpo, method="POST",
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            detalle = json.loads(e.read().decode("utf-8"))
            msg = detalle.get("error_description") or detalle.get("error") or str(e)
        except Exception:
            msg = str(e)
        raise ErrorDrive("Google no aceptó la petición: %s" % msg)
    except urllib.error.URLError as e:
        raise ErrorDrive("No hay conexión con Google: %s" % e.reason)


def intercambiar_codigo(datos_dir, client_id, code, state):
    pkce = _leer_json(_ruta(datos_dir, "drive_pkce.json"))
    if not pkce or state != pkce.get("state"):
        raise ErrorDrive("El inicio de sesión no coincide con el que se pidió (estado no válido).")
    # Comprobar caducidad (10 minutos) para no dejar un verificador viejo.
    try:
        creado = dt.datetime.fromisoformat(pkce["creado"])
        if (dt.datetime.now() - creado).total_seconds() > 600:
            raise ErrorDrive("El inicio de sesión caducó: vuelve a pulsar Conectar.")
    except ErrorDrive:
        raise
    except Exception:
        pass
    resp = _post_form(TOKEN_URL, {"client_id": client_id, "redirect_uri": pkce["redirect_uri"],
                                  "grant_type": "authorization_code", "code": code,
                                  "code_verifier": pkce["verifier"]})
    if "access_token" not in resp:
        raise ErrorDrive("Google no devolvió un token de acceso.")
    token = {"access_token": resp["access_token"],
             "refresh_token": resp.get("refresh_token"),
             "expires_at": (dt.datetime.now() + dt.timedelta(seconds=int(resp.get("expires_in", 3600)) - 60)).isoformat(),
             "scope": resp.get("scope", SCOPE)}
    if not token["refresh_token"]:
        raise ErrorDrive("Google no devolvió un token de refresco: vuelve a conectar y acepta el permiso.")
    _guardar_token(datos_dir, token)
    try:
        os.remove(_ruta(datos_dir, "drive_pkce.json"))
    except OSError:
        pass
    return token


def _token_valido(datos_dir, client_id):
    token = leer_token(datos_dir)
    if not token or not token.get("access_token"):
        raise ErrorDrive("Drive no está conectado.")
    try:
        expira = dt.datetime.fromisoformat(token.get("expires_at", ""))
        if expira > dt.datetime.now() + dt.timedelta(seconds=30):
            return token
    except Exception:
        pass
    # Refrescar.
    if not token.get("refresh_token"):
        raise ErrorDrive("Drive no está conectado (falta el token de refresco).")
    resp = _post_form(TOKEN_URL, {"client_id": client_id, "grant_type": "refresh_token",
                                  "refresh_token": token["refresh_token"]})
    if "access_token" not in resp:
        raise ErrorDrive("No se pudo renovar el acceso a Drive: vuelve a conectar.")
    token["access_token"] = resp["access_token"]
    token["expires_at"] = (dt.datetime.now() + dt.timedelta(seconds=int(resp.get("expires_in", 3600)) - 60)).isoformat()
    _guardar_token(datos_dir, token)
    return token


# ------------------------------------------------------------------ Drive API

def _llamada_drive(method, url, token, datos=None, content_type=None):
    headers = {"Authorization": "Bearer " + token["access_token"]}
    if content_type:
        headers["Content-Type"] = content_type
    req = urllib.request.Request(url, data=datos, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            cuerpo = r.read()
            return json.loads(cuerpo.decode("utf-8")) if cuerpo else {}
    except urllib.error.HTTPError as e:
        cuerpo = e.read().decode("utf-8", "replace")
        raise ErrorDrive("Drive devolvió %s: %s" % (e.code, cuerpo[:200]))


def _buscar_archivo(token):
    q = "name = '%s' and trashed = false" % NOMBRE_ARCHIVO
    url = FILES_URL + "?" + urllib.parse.urlencode(
        {"q": q, "spaces": "appDataFolder", "fields": "files(id,name,modifiedTime)"})
    resp = _llamada_drive("GET", url, token)
    archivos = resp.get("files") or []
    return archivos[0]["id"] if archivos else None


def _descargar(token, file_id):
    url = FILES_URL + "/" + urllib.parse.quote(file_id) + "?alt=media"
    headers = {"Authorization": "Bearer " + token["access_token"]}
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        raise ErrorDrive("No se pudo descargar de Drive (%s)." % e.code)


def _subir(token, file_id, contenido):
    if file_id:
        url = UPLOAD_URL + "/" + urllib.parse.quote(file_id) + "?uploadType=media"
        _llamada_drive("PATCH", url, token, datos=contenido, content_type="application/json")
        return file_id
    # Multipart: metadatos + contenido.
    frontera = "----aurea" + secrets.token_hex(16)
    meta = json.dumps({"name": NOMBRE_ARCHIVO, "parents": ["appDataFolder"]}, ensure_ascii=False)
    cuerpo = (("--" + frontera + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" + meta + "\r\n"
               "--" + frontera + "\r\nContent-Type: application/json\r\n\r\n").encode("utf-8")
              + contenido + ("\r\n--" + frontera + "--\r\n").encode("utf-8"))
    resp = _llamada_drive("POST", UPLOAD_URL + "?uploadType=multipart", token, datos=cuerpo,
                          content_type="multipart/related; boundary=" + frontera)
    return resp.get("id")


# ------------------------------------------------------------------ sincronizar

def _normalizar(v):
    """Normaliza un estado para compararlo: las listas con id se ordenan
    por id, porque el orden en que cada dispositivo las guardó no es un
    cambio real. Sin esto, dos dispositivos se subirían el archivo una y
    otra vez solo por tener los movimientos en distinto orden."""
    if isinstance(v, dict):
        return {k: _normalizar(x) for k, x in sorted(v.items())}
    if isinstance(v, list):
        if v and all(isinstance(x, dict) and x.get("id") is not None for x in v):
            return sorted((_normalizar(x) for x in v), key=lambda x: str(x["id"]))
        return [_normalizar(x) for x in v]
    return v


def _hash_estado(estado):
    datos = {"carteras": estado.get("carteras") or {}, "presupuesto": estado.get("presupuesto"),
             "perfiles": estado.get("perfiles")}
    return hashlib.sha256(json.dumps(_normalizar(datos), ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()


def sincronizar(datos_dir, client_id=None):
    """Sincroniza con Drive. Devuelve un resumen. No borra nada en silencio:
    mezcla con sincronizar.fusionar() y avisa de conflictos en el resumen."""
    config = leer_config(datos_dir)
    client_id = client_id or config.get("client_id")
    if not client_id:
        raise ErrorDrive("Falta el ID de cliente de Google: configúralo en Sincronización.")
    try:
        token = _token_valido(datos_dir, client_id)
        local = _sync.leer_estado(datos_dir)
        if not local.get("carteras"):
            raise ErrorDrive("Todavía no tienes una cartera propia que sincronizar.")
        base = _sync.leer_base(datos_dir)
        file_id = _buscar_archivo(token)
        if not file_id:
            contenido = json.dumps(_sync.archivo_exportar(local, "Aurea"),
                                   ensure_ascii=False, indent=1).encode("utf-8")
            _subir(token, None, contenido)
            _sync.guardar_base(datos_dir, local)
            resumen = {"subido": True, "anadidos": 0, "actualizados": 0, "borrados": 0, "conflictos": []}
            _actualizar_estado(datos_dir, resultado=resumen, error=None)
            return resumen
        remoto_bytes = _descargar(token, file_id)
        try:
            remoto_datos = json.loads(remoto_bytes.decode("utf-8"))
            _sync.validar_archivo(remoto_datos)
        except Exception as e:
            raise ErrorDrive("El archivo de Drive no es válido: %s" % e)
        otro = {"carteras": remoto_datos["carteras"], "presupuesto": remoto_datos.get("presupuesto"),
                "perfiles": remoto_datos.get("perfiles")}
        if _hash_estado(local) == _hash_estado(otro):
            # Ya iguales: solo actualizar la base si hacía falta.
            if _hash_estado(base) != _hash_estado(local):
                _sync.guardar_base(datos_dir, local)
            resumen = {"subido": False, "anadidos": 0, "actualizados": 0, "borrados": 0, "conflictos": []}
            _actualizar_estado(datos_dir, resultado=resumen, error=None)
            return resumen
        mezclado, resumen = _sync.fusionar(local, otro, base)
        if _hash_estado(mezclado) != _hash_estado(local):
            _sync.escribir_estado(datos_dir, mezclado)
        _sync.guardar_base(datos_dir, mezclado)
        subido = False
        if _hash_estado(mezclado) != _hash_estado(otro):
            contenido = json.dumps(_sync.archivo_exportar(mezclado, "Aurea"),
                                   ensure_ascii=False, indent=1).encode("utf-8")
            _subir(token, file_id, contenido)
            subido = True
        resumen = dict(resumen, subido=subido)
        _actualizar_estado(datos_dir, resultado=resumen, error=None)
        return resumen
    except ErrorDrive as e:
        _actualizar_estado(datos_dir, error=str(e))
        raise
    except Exception as e:
        _actualizar_estado(datos_dir, error=str(e))
        raise ErrorDrive("No se pudo sincronizar con Drive: %s" % e)


def sincronizar_silencioso(datos_dir):
    """Para llamar en segundo plano al guardar o al abrir: nunca rompe la
    app si Drive falla o no hay conexión; solo deja el error en el estado."""
    try:
        config = leer_config(datos_dir)
        token = leer_token(datos_dir)
        if not config.get("client_id") or not token:
            return None
        return sincronizar(datos_dir)
    except Exception:
        return None
