# -*- coding: utf-8 -*-
"""Sincronización bidireccional entre dos copias de la app (móvil y escritorio).

Sin nube, sin servidor externo y sin cuentas: los dos dispositivos se pasan
un archivo de sincronización (por WhatsApp, correo, Drive, USB...) y cada uno
mezcla los cambios del otro con los suyos.

Formato del archivo:
    {"version": 1, "fecha": "2026-10-25T19:00:00", "origen": "Aurea",
     "carteras": {"propio": {...cartera...}, "otro_perfil": {...}},
     "presupuesto": {...} o null, "perfiles": {...} o null}

Cómo se mezcla (lo importante):
    Cada dispositivo guarda, en sincronizar/base.json, el estado que tenía
    la última vez que sincronizó (la "base"). Al importar un archivo, se
    compara: base vs. lo que hay aquí vs. lo que viene en el archivo.
      * Si solo un lado cambió algo, se queda con ese cambio.
      * Si los dos añadieron cosas distintas, se quedan las dos.
      * Si los dos cambiaron lo mismo de forma distinta, se queda la
        versión de este dispositivo y se avisa del conflicto en el resumen.
        Nunca se borra nada en silencio.
      * Si un lado borró algo y el otro lo editó, se recupera lo editado
        y se avisa, para no perder datos.
    Los movimientos y valoraciones tienen id (m1, m2... / v1, v2...). Si los
    dos lados crean un registro nuevo con el mismo id pero distinto contenido
    (puede pasar si no se sincronizó antes), se quedan los dos y al que viene
    de fuera se le da un id nuevo libre: no se duplica ni se pierde nada.
    Los productos se identifican por su id (slug): si los dos crean un
    producto con el mismo id pero distinto, es conflicto y se avisa.

No se sincronizan: la caché de precios, los calculados ni el estado de
precios. Eso lo recalcula cada dispositivo al abrir, con sus precios
guardados. Solo viajan cartera, presupuesto y perfiles, que es lo que el
usuario edita.
"""

import copy
import json
import os
import re
import shutil

VERSION = 1
CARPETA_SYNC = "sincronizar"
ARCHIVO_BASE = "base.json"

# Claves de cartera que son listas con id (se mezclan por id).
LISTAS_CON_ID = ("productos", "movimientos", "valoraciones", "comparador")
# Prefijo de id para reasignar colisiones en registros nuevos.
PREFIJO_ID = {"movimientos": "m", "valoraciones": "v"}


class ErrorSync(Exception):
    pass


# ------------------------------------------------------------------ validación

def _es_numero(x):
    return x is None or (isinstance(x, (int, float)) and not isinstance(x, bool))


def validar_cartera(cfg):
    """Validación parecida a la de las copias: solo estructura, sin Flask."""
    if not isinstance(cfg, dict):
        raise ErrorSync("La cartera no es un objeto.")
    for k in ("productos", "movimientos", "valoraciones"):
        if not isinstance(cfg.get(k), list):
            raise ErrorSync("La cartera no tiene %s como lista." % k)
    ids = set()
    for p in cfg["productos"]:
        if not isinstance(p, dict) or not re.fullmatch(r"[A-Za-z0-9_.\-]{1,80}", str(p.get("id") or "")):
            raise ErrorSync("Un producto no tiene un id válido.")
        ids.add(p["id"])
    for m in cfg["movimientos"]:
        if not isinstance(m, dict) or m.get("producto") not in ids:
            raise ErrorSync("Un movimiento apunta a un producto que no existe.")
        if not all(_es_numero(m.get(k)) for k in ("importe", "unidades", "unidadesDestino", "comision")):
            raise ErrorSync("Un movimiento tiene un número no válido.")
    for v in cfg["valoraciones"]:
        if not isinstance(v, dict) or v.get("producto") not in ids:
            raise ErrorSync("Una valoración apunta a un producto que no existe.")
        if not _es_numero(v.get("valor")) or not _es_numero(v.get("aportado")):
            raise ErrorSync("Una valoración tiene un número no válido.")
    return cfg


def validar_archivo(datos):
    if not isinstance(datos, dict) or datos.get("version") != VERSION:
        raise ErrorSync("Ese archivo no es un archivo de sincronización válido.")
    carteras = datos.get("carteras")
    if not isinstance(carteras, dict) or not carteras:
        raise ErrorSync("El archivo de sincronización no trae ninguna cartera.")
    for pid, cfg in carteras.items():
        if not isinstance(pid, str) or not pid:
            raise ErrorSync("El archivo trae un perfil sin nombre.")
        validar_cartera(cfg)
    return datos


# ------------------------------------------------------------------ ayudas

def _igual(a, b):
    return json.dumps(a, ensure_ascii=False, sort_keys=True) == json.dumps(b, ensure_ascii=False, sort_keys=True)


def _por_id(lista):
    out = {}
    for x in lista or []:
        if isinstance(x, dict) and x.get("id") is not None:
            out[str(x["id"])] = x
    return out


def _siguiente_id(lista, prefijo):
    nums = []
    for x in lista or []:
        if isinstance(x, dict):
            m = re.fullmatch(prefijo + r"(\d+)", str(x.get("id") or ""))
            if m:
                nums.append(int(m.group(1)))
    return "%s%d" % (prefijo, (max(nums) + 1) if nums else 1)


def _mezclar_listas(local, otro, base, tipo, perfil, resumen, conflictos):
    """Mezcla tres versiones de una lista con id. Devuelve la lista mezclada."""
    l, o, b = _por_id(local), _por_id(otro), _por_id(base)
    # Registros sin id (no debería pasar, pero no se pierden): se añaden si
    # no están ya por contenido.
    sin_id = [x for x in (local or []) if not isinstance(x, dict) or x.get("id") is None]
    for x in (otro or []):
        if (not isinstance(x, dict) or x.get("id") is None) and not any(_igual(x, y) for y in sin_id):
            sin_id.append(x)
    resultado = {}
    orden = []
    # Orden: primero la base (lo que ya existía), luego lo nuevo local, luego lo nuevo de fuera.
    for rid in b:
        orden.append(rid)
    for rid in l:
        if rid not in orden:
            orden.append(rid)
    for rid in o:
        if rid not in orden:
            orden.append(rid)
    for rid in orden:
        en_l, en_o, en_b = rid in l, rid in o, rid in b
        if en_l and en_o:
            if _igual(l[rid], o[rid]):
                resultado[rid] = copy.deepcopy(l[rid])
            elif en_b and _igual(l[rid], b[rid]):
                resultado[rid] = copy.deepcopy(o[rid])
                resumen["actualizados"] += 1
            elif en_b and _igual(o[rid], b[rid]):
                resultado[rid] = copy.deepcopy(l[rid])
            elif not en_b:
                # Los dos crearon un registro nuevo con el mismo id.
                if tipo in PREFIJO_ID:
                    # Movimientos y valoraciones: se quedan los dos, al de
                    # fuera se le da un id nuevo libre.
                    resultado[rid] = copy.deepcopy(l[rid])
                    nuevo = copy.deepcopy(o[rid])
                    nuevo_id = _siguiente_id(list(resultado.values()) + sin_id, PREFIJO_ID[tipo])
                    nuevo["id"] = nuevo_id
                    resultado[nuevo_id] = nuevo
                    resumen["anadidos"] += 1
                    conflictos.append("%s · %s: los dos añadisteis un %s con el id %s; "
                                      "el de fuera se guardó como %s para no perderlo."
                                      % (perfil, tipo, tipo[:-1], rid, nuevo_id))
                else:
                    resultado[rid] = copy.deepcopy(l[rid])
                    conflictos.append("%s · %s %s: los dos lo creasteis distinto; "
                                      "me quedo con la versión de este dispositivo." % (perfil, tipo, rid))
            else:
                resultado[rid] = copy.deepcopy(l[rid])
                conflictos.append("%s · %s %s: cambiado en los dos lados; "
                                  "me quedo con la versión de este dispositivo." % (perfil, tipo, rid))
        elif en_l and not en_o:
            if en_b and _igual(l[rid], b[rid]):
                resumen["borrados"] += 1  # borrado fuera, sin cambios aquí
            elif en_b:
                resultado[rid] = copy.deepcopy(l[rid])  # editado aquí, borrado fuera: se recupera
                conflictos.append("%s · %s %s: lo editaste aquí y se borró fuera; "
                                  "lo recupero para no perderlo." % (perfil, tipo, rid))
            else:
                resultado[rid] = copy.deepcopy(l[rid])  # solo local
        elif en_o and not en_l:
            if en_b and _igual(o[rid], b[rid]):
                resumen["borrados"] += 1  # borrado aquí, sin cambios fuera
            elif en_b:
                resultado[rid] = copy.deepcopy(o[rid])  # editado fuera, borrado aquí: se recupera
                conflictos.append("%s · %s %s: se editó fuera y se borró aquí; "
                                  "lo recupero para no perderlo." % (perfil, tipo, rid))
            else:
                resultado[rid] = copy.deepcopy(o[rid])
                resumen["anadidos"] += 1
    # Los registros sin id van al final, sin duplicar. Los ids reasignados
    # en una colisión no estaban en `orden`: se añaden al final también.
    lista = [resultado[rid] for rid in orden if rid in resultado]
    lista += [v for k, v in resultado.items() if k not in orden]
    return lista + sin_id


def _mezclar_valor(local, otro, base, ruta, resumen, conflictos):
    """Mezcla un valor escalar o un dict (recursivo). Devuelve el valor mezclado."""
    if _igual(local, otro):
        return copy.deepcopy(local)
    if _igual(local, base):
        return copy.deepcopy(otro)
    if _igual(otro, base):
        return copy.deepcopy(local)
    if isinstance(local, dict) and isinstance(otro, dict) and isinstance(base, dict):
        out = {}
        for k in sorted(set(local) | set(otro) | set(base)):
            if k in local and k in otro and k in base:
                out[k] = _mezclar_valor(local[k], otro[k], base[k], ruta + "." + str(k), resumen, conflictos)
            elif k in local and k in otro:
                # Añadido en los dos lados con distinto contenido: conflicto.
                out[k] = copy.deepcopy(local[k])
                conflictos.append("%s: cambiado en los dos lados; me quedo con la versión de este dispositivo." % (ruta + "." + str(k)))
            elif k in otro:
                out[k] = copy.deepcopy(otro[k])
            elif k in local:
                # Borrado fuera o añadido aquí: si estaba en base, fuera lo borró.
                if k in base and _igual(local[k], base[k]):
                    pass  # borrado fuera
                else:
                    out[k] = copy.deepcopy(local[k])
            # Si solo estaba en base, se borró en los dos: no se añade.
        return out
    # Conflicto en un valor escalar: se queda lo local y se avisa.
    conflictos.append("%s: cambiado en los dos lados; me quedo con la versión de este dispositivo." % ruta)
    return copy.deepcopy(local)


def _mezclar_cartera(local, otro, base, perfil, resumen, conflictos):
    local = local or {}
    otro = otro or {}
    base = base or {}
    out = {}
    for k in sorted(set(local) | set(otro) | set(base)):
        if k in LISTAS_CON_ID:
            antes = len(out)  # no se usa, solo para claridad
            out[k] = _mezclar_listas(local.get(k), otro.get(k), base.get(k), k, perfil, resumen, conflictos)
        elif k in local and k in otro and k in base:
            out[k] = _mezclar_valor(local[k], otro[k], base[k], "%s.%s" % (perfil, k), resumen, conflictos)
        elif k in local and k in otro:
            if _igual(local[k], otro[k]):
                out[k] = copy.deepcopy(local[k])
            else:
                out[k] = copy.deepcopy(local[k])
                conflictos.append("%s.%s: cambiado en los dos lados; me quedo con la versión de este dispositivo." % (perfil, k))
        elif k in otro:
            out[k] = copy.deepcopy(otro[k])
        elif k in local:
            if k in base and _igual(local[k], base[k]):
                pass  # borrado fuera
            else:
                out[k] = copy.deepcopy(local[k])
    # Garantizar las claves que el resto de la app espera.
    for k in ("productos", "movimientos", "valoraciones"):
        out.setdefault(k, [])
    return out


def fusionar(local, otro, base):
    """Fusiona otro estado con el local, usando base como última sincronización.

    local, otro, base: dicts con "carteras" (perfil -> cartera), "presupuesto"
    y "perfiles". Devuelve (mezclado, resumen) donde resumen tiene contadores
    y la lista de conflictos (texto).
    """
    local, otro, base = local or {}, otro or {}, base or {}
    resumen = {"anadidos": 0, "actualizados": 0, "borrados": 0, "perfiles": 0}
    conflictos = []
    carteras_l = local.get("carteras") or {}
    carteras_o = otro.get("carteras") or {}
    carteras_b = base.get("carteras") or {}
    mezcladas = {}
    for pid in sorted(set(carteras_l) | set(carteras_o) | set(carteras_b)):
        if pid not in carteras_l and pid not in carteras_o:
            continue  # borrado en los dos
        if pid not in carteras_l:
            mezcladas[pid] = copy.deepcopy(carteras_o[pid])
            resumen["perfiles"] += 1
        elif pid not in carteras_o:
            mezcladas[pid] = copy.deepcopy(carteras_l[pid])
        else:
            mezcladas[pid] = _mezclar_cartera(carteras_l[pid], carteras_o[pid], carteras_b.get(pid), pid, resumen, conflictos)
    presupuesto = _mezclar_valor(local.get("presupuesto"), otro.get("presupuesto"), base.get("presupuesto"),
                                 "presupuesto", resumen, conflictos)
    perfiles = _mezclar_valor(local.get("perfiles"), otro.get("perfiles"), base.get("perfiles"),
                              "perfiles", resumen, conflictos)
    mezclado = {"carteras": mezcladas}
    if presupuesto is not None:
        mezclado["presupuesto"] = presupuesto
    if perfiles is not None:
        mezclado["perfiles"] = perfiles
    resumen["conflictos"] = conflictos
    return mezclado, resumen


# ------------------------------------------------------------------ disco

def _leer_json(ruta, defecto=None):
    try:
        with open(ruta, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return defecto


def _escribir_json(ruta, datos):
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    tmp = ruta + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=1)
    os.replace(tmp, ruta)


def leer_estado(datos_dir):
    """Lee el estado sincronizable de una carpeta de datos (móvil o escritorio).

    Solo perfiles con cartera.json real (la demo no cuenta: no es una cartera
    propia). El perfil principal vive en la raíz; los demás, en perfiles/<id>/.
    """
    carteras = {}
    principal = os.path.join(datos_dir, "cartera.json")
    if os.path.exists(principal):
        cfg = _leer_json(principal)
        if cfg is not None:
            carteras["propio"] = cfg
    perfiles_dir = os.path.join(datos_dir, "perfiles")
    if os.path.isdir(perfiles_dir):
        for pid in sorted(os.listdir(perfiles_dir)):
            ruta = os.path.join(perfiles_dir, pid, "cartera.json")
            if os.path.exists(ruta):
                cfg = _leer_json(ruta)
                if cfg is not None:
                    carteras[pid] = cfg
    estado = {"carteras": carteras}
    presupuesto = _leer_json(os.path.join(datos_dir, "presupuesto.json"))
    if presupuesto is not None:
        estado["presupuesto"] = presupuesto
    perfiles = _leer_json(os.path.join(datos_dir, "perfiles.json"))
    if perfiles is not None:
        estado["perfiles"] = perfiles
    return estado


def escribir_estado(datos_dir, estado):
    """Escribe un estado mezclado, haciendo copia de seguridad antes.

    Antes de tocar nada, guarda el estado anterior como archivo de
    sincronización en sincronizar/antes_<fecha>.json, por si hay que volver.
    Después de escribir, borra los calculados: cada dispositivo los
    recalcula al abrir con sus precios guardados.
    """
    import datetime as dt
    carpeta = os.path.join(datos_dir, CARPETA_SYNC)
    os.makedirs(carpeta, exist_ok=True)
    anterior = leer_estado(datos_dir)
    if anterior.get("carteras"):
        sello = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        _escribir_json(os.path.join(carpeta, "antes_%s.json" % sello),
                       {"version": VERSION, "fecha": dt.datetime.now().isoformat(timespec="seconds"),
                        "origen": "copia antes de sincronizar", "carteras": anterior["carteras"],
                        "presupuesto": anterior.get("presupuesto"), "perfiles": anterior.get("perfiles")})
    for pid, cfg in (estado.get("carteras") or {}).items():
        if pid == "propio":
            _escribir_json(os.path.join(datos_dir, "cartera.json"), cfg)
        else:
            _escribir_json(os.path.join(datos_dir, "perfiles", pid, "cartera.json"), cfg)
    if estado.get("presupuesto") is not None:
        _escribir_json(os.path.join(datos_dir, "presupuesto.json"), estado["presupuesto"])
    if estado.get("perfiles") is not None:
        _escribir_json(os.path.join(datos_dir, "perfiles.json"), estado["perfiles"])
    for viejo in ("calculado_propio.json", "calculado_todos.json", "historico.json"):
        for raiz in [datos_dir] + [os.path.join(datos_dir, "perfiles", pid)
                                    for pid in (estado.get("carteras") or {}) if pid != "propio"]:
            ruta = os.path.join(raiz, viejo)
            if os.path.exists(ruta):
                try:
                    os.remove(ruta)
                except OSError:
                    pass


def leer_base(datos_dir):
    return _leer_json(os.path.join(datos_dir, CARPETA_SYNC, ARCHIVO_BASE)) or {}


def guardar_base(datos_dir, estado):
    _escribir_json(os.path.join(datos_dir, CARPETA_SYNC, ARCHIVO_BASE), estado)


def archivo_exportar(estado, origen):
    import datetime as dt
    return {"version": VERSION, "fecha": dt.datetime.now().isoformat(timespec="seconds"),
            "origen": origen, "carteras": estado.get("carteras") or {},
            "presupuesto": estado.get("presupuesto"), "perfiles": estado.get("perfiles")}


def importar_archivo(datos_dir, datos_archivo):
    """Mezcla un archivo de sincronización en esta carpeta de datos.

    Devuelve (resumen, estado_mezclado). La base se actualiza al estado
    mezclado: la próxima sincronización solo tendrá en cuenta los cambios
    que se hagan a partir de aquí, en cualquiera de los dos lados.
    """
    validar_archivo(datos_archivo)
    otro = {"carteras": datos_archivo["carteras"],
            "presupuesto": datos_archivo.get("presupuesto"),
            "perfiles": datos_archivo.get("perfiles")}
    # Un archivo antiguo (copia de seguridad) trae solo una cartera: se trata
    # como un estado con ese perfil principal.
    local = leer_estado(datos_dir)
    base = leer_base(datos_dir)
    mezclado, resumen = fusionar(local, otro, base)
    escribir_estado(datos_dir, mezclado)
    guardar_base(datos_dir, mezclado)
    return resumen, mezclado
