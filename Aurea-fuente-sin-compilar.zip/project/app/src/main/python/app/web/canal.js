/* Aurea para Android: sin referencias al autor ni a canales externos. */
window.CANAL = {autor: '', canal: '', suscribir: '', novedades: '', tutorial: ''};
