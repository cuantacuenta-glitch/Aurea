# -*- coding: utf-8 -*-
"""Arranque de Aurea dentro de Android (Chaquopy).

No se llama a servidor.main() (que abriría un navegador de escritorio):
se levanta el mismo servidor Flask en 127.0.0.1 y se devuelve
"puerto:llave" para que el WebView lo abra con su llave de acceso.
Los datos quedan en la carpeta privada de la app (filesDir/aurea_datos).
"""
import os
import threading

_SERVIDOR = None
_PUERTO = None


def iniciar(datos_dir, puerto=8765):
    global _SERVIDOR, _PUERTO
    if _SERVIDOR is not None:
        from app import servidor as _s
        return "%d:%s" % (_PUERTO, _s.token_acceso())
    os.environ["PATRIMONIO_DATOS"] = datos_dir
    os.environ["PATRIMONIO_PUERTO"] = str(puerto)
    os.environ["PATRIMONIO_HOST"] = "127.0.0.1"
    os.makedirs(datos_dir, exist_ok=True)

    from app import servidor
    from werkzeug.serving import make_server

    # Por si Chaquopy extrae los archivos en una ruta distinta a la esperada,
    # corregir WEB/DEMO y recalcular el CSP de los scripts en línea.
    raiz = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    web = os.path.join(raiz, "app", "web")
    if os.path.isdir(web):
        servidor.RAIZ = raiz
        servidor.WEB = web
        servidor.DEMO = os.path.join(raiz, "demo", "cartera.json")
        huellas = servidor._hashes_en_linea()
        servidor.CSP = "; ".join([
            "default-src 'self'",
            "script-src 'self' " + " ".join(huellas),
            "style-src 'self' 'unsafe-inline'",
            "img-src 'self' data:",
            "connect-src 'self' https://api.coingecko.com https://api.binance.com",
            "font-src 'self'", "object-src 'none'", "base-uri 'none'", "form-action 'self'",
            "frame-ancestors 'none'",
        ])

    def trabajo():
        # Android, arranque rápido: NO descargar precios al abrir.
        # Antes se hacía aquí y bloqueaba la app: las series se bajan
        # una a una (hasta 30 s por fuente) bajo el cerrojo, y casi
        # siempre saltaba porque los precios tienen más de 6 horas.
        # Se arranca con los precios guardados y los frescos se piden
        # a mano con «Actualizar precios», que ya existe en la app.
        try:
            servidor.recalcula(descargar=False)
        except Exception:
            pass
        # Drive en segundo plano (no bloquea el arranque): si el otro
        # dispositivo cambió algo, se mezcla; el frontal lo recarga al abrir.
        try:
            from app import drive_sync
            drive_sync.sincronizar_silencioso(datos_dir)
        except Exception:
            pass

    def servir():
        try:
            _SERVIDOR.serve_forever()
        except Exception:
            pass

    srv = None
    for p in range(int(puerto), int(puerto) + 10):
        try:
            srv = make_server("127.0.0.1", p, servidor.app, threaded=True)
            _PUERTO = p
            break
        except OSError:
            continue
    if srv is None:
        raise RuntimeError("No hay puerto libre para Aurea")
    _SERVIDOR = srv
    threading.Thread(target=servir, daemon=True).start()
    threading.Thread(target=trabajo, daemon=True).start()
    return "%d:%s" % (_PUERTO, servidor.token_acceso())
